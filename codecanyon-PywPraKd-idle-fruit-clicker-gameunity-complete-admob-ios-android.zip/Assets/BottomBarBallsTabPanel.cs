﻿// /*
// Created by Darsan
// */

using UnityEngine;

public class BottomBarBallsTabPanel : BottomBarTabPanel
{
    [SerializeField] private BallTileUI _ballPrefab;
    [SerializeField] private RectTransform _content;
    [SerializeField] private BallUpgradePopOverPanel _ballPopOverPanel;

    public override BottomBarTab Tab => BottomBarTab.Fruits;

    private BallSystem BallSystem => LevelManager.Instance.BallSystem;

    private void Start()
    {
        foreach (var modelBall in BallSystem.ModelBalls)
        {
            var ballTileUI = Instantiate(_ballPrefab,_content);
            ballTileUI.MViewModel = new BallTileUI.ViewModel
            {
                Ball = modelBall,
                Locked = BallSystem.IsBallGroupLocked(modelBall.groupId)
            }; 
            ballTileUI.Clicked +=BallTileUIOnClicked;
        }
    }

    private void OnDisable()
    {
        if (_ballPopOverPanel.Showing)
        {
            _ballPopOverPanel.Hide();
        }
    }

    private void BallTileUIOnClicked(BallTileUI tile)
    {

        if (_ballPopOverPanel.CurrentShowState == ShowState.Show && _ballPopOverPanel.Ball.groupId == tile.MViewModel.Ball.groupId)
        {
            _ballPopOverPanel.Hide();
            return;
        }


        if (BallSystem.IsBallGroupLocked(tile.MViewModel.Ball.groupId))
        {
            if (_ballPopOverPanel.CurrentShowState == ShowState.Show)
            {
                _ballPopOverPanel.Hide();
                return;
            }

            if (tile.MViewModel.Ball.lockDetails.useCoins && ResourceManager.Coins >= tile.MViewModel.Ball.lockDetails.unlockCoins)
            {
                ResourceManager.Coins -= tile.MViewModel.Ball.lockDetails.unlockCoins;
                BallSystem.UnlockBallGroup(tile.MViewModel.Ball.groupId);

                var tileMViewModel = tile.MViewModel;
                tileMViewModel.Locked = BallSystem.IsBallGroupLocked(tile.MViewModel.Ball.groupId);
                tile.MViewModel = tileMViewModel;
            }
            else if(tile.MViewModel.Ball.lockDetails.hasVideoUnLock)
            {
                AdsManager.ShowVideoAds(true, success =>
                {
                    if(!success)
                        return;
                    BallSystem.UnlockBallGroup(tile.MViewModel.Ball.groupId);
                    var tileMViewModel = tile.MViewModel;
                    tileMViewModel.Locked = BallSystem.IsBallGroupLocked(tile.MViewModel.Ball.groupId);
                    tile.MViewModel = tileMViewModel;
                });
            }
        }
        else
        {

            _ballPopOverPanel.Ball = tile.MViewModel.Ball;
            _ballPopOverPanel.PopOverPointX = tile.transform.position.x;
            if(!_ballPopOverPanel.Showing)
            _ballPopOverPanel.Show();
        }
    }
}