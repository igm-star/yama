﻿using System;
using Game;
using UnityEngine;
using Object = UnityEngine.Object;

public partial class EffectPanel : MonoBehaviour
{


    public T PlayEffect<T>(T effect, Vector3 screenPosition) where T : Object
    {
        var obj = Instantiate(effect, transform);

        if (obj is GameObject go)
        {
            go.transform.position = screenPosition;
        }
        else if (obj is Component component)
        {
            component.transform.position = screenPosition;
        }
        return obj;
    }

}

public partial class EffectPanel
{
    [SerializeField] private MoneyUIEffect _moneyUIEffect;
    [SerializeField] private GameObject _tapEffect;


    public GameObject TapEffect => _tapEffect;
    public MoneyUIEffect MoneyUIEffect => _moneyUIEffect;

    private float _pressElapsedTime;
    private Vector2 _lastMousePosition;




    private void OnEnable()
    {
        LevelManager.TargetClicked += LevelManagerOnTargetClicked;    
        LevelManager.EarnedCoinsByTargetDamage += LevelManagerOnEarnedCoinsByTargetDamage;    
    }

    private void LevelManagerOnEarnedCoinsByTargetDamage(Target target, int val, Vector2 point)
    {
        var effectPanel = UIManager.Instance.EffectPanel;
        var moneyUIEffect = effectPanel.PlayEffect(effectPanel.MoneyUIEffect, Camera.main.WorldToScreenPoint(point));
        moneyUIEffect.Money = val;
        moneyUIEffect.Earn = true;
    }

    private void OnDisable()
    {
        LevelManager.TargetClicked -= LevelManagerOnTargetClicked;    
    }

    private void LevelManagerOnTargetClicked(Target obj)
    {
        PlayEffect(TapEffect, Input.mousePosition);
    }
}