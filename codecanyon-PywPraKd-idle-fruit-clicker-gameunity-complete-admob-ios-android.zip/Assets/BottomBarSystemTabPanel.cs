﻿// /*
// Created by Darsan
// */

using System;
using UnityEngine;

public class BottomBarSystemTabPanel : BottomBarTabPanel
{
    [SerializeField] private SystemTileUI _tapTileUI,_speedUpgradeTileUI, _earningUpgradeTileUI;

    public override BottomBarTab Tab => BottomBarTab.System;
    public LevelManager LevelManager=>LevelManager.Instance;

    private void Start()
    {
        _speedUpgradeTileUI.Clicked +=UpgradeTileUIOnClicked;
        _earningUpgradeTileUI.Clicked +=UpgradeTileUIOnClicked;
        _tapTileUI.Clicked += UpgradeTileUIOnClicked;
        RefreshMainProperties();
    }

    private void OnEnable()
    {
        LevelManager.PropertyUpgraded += BallSystemOnPropertyUpgraded;
    }

    private void OnDisable()
    {
        LevelManager.PropertyUpgraded -= BallSystemOnPropertyUpgraded;
    }

    private void BallSystemOnPropertyUpgraded(ISystemProperty systemProperty)
    {
        RefreshMainProperties();
    }

    private void UpgradeTileUIOnClicked(SimpleBtn btn)
    {
        var systemTileUI = (SystemTileUI)btn;
        if (systemTileUI.UseCoins)
        {
            ResourceManager.Coins -= systemTileUI.MViewModel.LockDetails.unlockCoins;
            LevelManager.UpdateProperty(systemTileUI.MViewModel.SystemProperty);
        }
        else
        {
            if (!AdsManager.IsVideoAvailable())
            {
                var popUpPanel = UIManager.Instance.PopUpPanel;
                popUpPanel.ShowAsInfo("No Ads", "Please turn on your internet connection!");
                return;
            }

            AdsManager.ShowVideoAds(true,success =>
            {
                if (success)
                    LevelManager.UpdateProperty(systemTileUI.MViewModel.SystemProperty);
            });
        }
    }

    private void RefreshMainProperties(params string[] properties)
    {
        if (properties.Length == 0)
        {
            RefreshMainProperties(nameof(LevelManager.TapEarning),nameof(LevelManager.SpeedMultiplexer), nameof(LevelManager.EarningsMultiplexer));
            return;
        }

        foreach (var property in properties)
        {
            var upgradeProperty = LevelManager.GetUpgradeProperty(property);
            switch (property)
            {


                case nameof(LevelManager.EarningsMultiplexer):
                    _earningUpgradeTileUI.MViewModel = new SystemTileUI.ViewModel
                    {
                        SystemProperty = upgradeProperty,
                        LockDetails = LevelManager.GetLockDetailsForUpgrade(property),
                        SubTitle = $"Level {upgradeProperty.Index}"
                    };
                    break;

                case nameof(LevelManager.SpeedMultiplexer):
                    _speedUpgradeTileUI.MViewModel = new SystemTileUI.ViewModel
                    {
                        SystemProperty = upgradeProperty,
                        LockDetails = LevelManager.GetLockDetailsForUpgrade(property),
                        SubTitle = $"Level {upgradeProperty.Index}"
                    };
                    break;
                case nameof(LevelManager.TapEarning):
                    _tapTileUI.MViewModel = new SystemTileUI.ViewModel
                    {
                        SystemProperty = upgradeProperty,
                        LockDetails = LevelManager.GetLockDetailsForUpgrade(property),
                        SubTitle = $"Level {upgradeProperty.Index}"
                    };
                    break;
            }
        }
    }
}