﻿// /*
// Created by Darsan
// */

using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Random = UnityEngine.Random;

public class BallSystem : MonoBehaviour
{
    public event Action<string, ISystemProperty> PropertyUpgraded;

    public static BallSystem Instance { get; private set; }


    public static IEnumerable<Model.Ball> ModelBalls => Model.Balls.Default;

    protected readonly Dictionary<string, List<ISystemProperty>> propertiesDict =
        new Dictionary<string, List<ISystemProperty>>();

    protected readonly List<Game.Ball> balls = new List<Game.Ball>();


    public IEnumerable<KeyValuePair<string, ISystemProperty[]>> GetGroupAndProperties()
    {
        return ModelBalls.Select(ball =>
            new KeyValuePair<string, ISystemProperty[]>(ball.groupId,
                GetPropertiesToBallGroup(ball.groupId).ToArray()));
    }

    private IEnumerable<ISystemProperty> GetInitialProperties(string ballId)
    {
        var locked = IsBallGroupLocked(ballId);
        return GetPropertiesAndUpgrades(ballId)
            .Select(upgrade =>
            {
                if (!locked && upgrade.id == "Count")
                    return upgrade.GetPropertyAt(0);
                return upgrade.GetPropertyAt(0);
            });
    }

    public IEnumerable<ISystemProperty> GetPropertiesToBallGroup(string groupId)
    {
        if (!propertiesDict.ContainsKey(groupId))
        {
            var json = PrefManager.GetString(groupId + "_Properties",
                JsonUtility.ToJson(new PropertiesData(GetInitialProperties(groupId))));
            var systemProperties = JsonUtility.FromJson<PropertiesData>
                (json).Select(property => (ISystemProperty) property);
            propertiesDict.Add(groupId, systemProperties.ToList());
        }

        return propertiesDict[groupId];
    }

    public IEnumerable<Game.Ball> GetBallsForGroup(string groupId) => balls.Where(ball => ball.GroupId == groupId);

    public void SetPropertiesToBallGroup(string groupId, IEnumerable<ISystemProperty> properties)
    {
        var list = properties.ToList();
        PrefManager.SetString(groupId + "_Properties", JsonUtility.ToJson(new PropertiesData(list)));

        if (!propertiesDict.ContainsKey(groupId))
        {
            propertiesDict.Add(groupId, new List<ISystemProperty>());
        }

        foreach (var systemProperty in list)
        {
            switch (systemProperty.Id)
            {
                case "Count":
                    while (GetBallsForGroup(groupId).Count() < systemProperty.Value)
                    {
                        var newBall = Instantiate(ModelBalls.First(ball => ball.groupId == groupId).ballPrefab);
                        SetPropertiesToBall(newBall, GetPropertiesToBallGroup(groupId));
                        balls.Add(newBall);
                    }

                    break;
            }
        }


        foreach (var ball in GetBallsForGroup(groupId))
        {
            SetPropertiesToBall(ball, list);
        }

        propertiesDict[groupId].Clear();
        propertiesDict[groupId].AddRange(list);
    }

    private static void SetPropertiesToBall(Game.Ball ball, IEnumerable<ISystemProperty> properties)
    {
        foreach (var systemProperty in properties)
        {
            switch (systemProperty.Id)
            {
                case "Speed":
                    ball.Speed = systemProperty.Value;
                    break;

                case "Earning":
                    ball.Earning = (int) systemProperty.Value;
                    break;
            }
        }
    }

    public IEnumerable<PropertyAndUpgrade> GetPropertiesAndUpgrades(string ball)
    {
        return ModelBalls.First(b => b.groupId == ball).PropertiesAndUpgrades;
    }

    public ISystemProperty GetCurrentProperty(string groupId, string id) => GetPropertiesToBallGroup(groupId).FirstOrDefault(property => property.Id == id);

    public ISystemProperty GetUpgradeProperty(string groupId, string id, out LockDetails lockDetails)
    {
        var systemProperty = GetPropertiesToBallGroup(groupId).FirstOrDefault(property => property.Id == id);

        if (systemProperty == null)
            throw new Exception(id);

        var propertyAndUpgrade = GetPropertiesAndUpgrades(groupId).FirstOrDefault(upgrade => upgrade.id == id);
        if (string.IsNullOrEmpty(propertyAndUpgrade.id))
            throw new Exception();

        //Fake for upper limit
        if (systemProperty.Index >= propertyAndUpgrade.TotalCount - 1)
        {
            if (systemProperty.Id == "Count")
            {
                lockDetails = new LockDetails();
                return null;
            }

            lockDetails = propertyAndUpgrade.GetLockDetails(propertyAndUpgrade.TotalCount - 1);

            if ( lockDetails.useCoins && Random.value>0.1f)
            {
                lockDetails.unlockCoins = lockDetails.unlockCoins +
                                          Mathf.RoundToInt((systemProperty.Index + 2 - (propertyAndUpgrade.TotalCount - 1))* lockDetails.unlockCoins * 0.3f);
            }
            else
            {
                lockDetails.useCoins = false;
                lockDetails.hasVideoUnLock = true;
            }

            var upgradeProperty = propertyAndUpgrade.GetPropertyAt(propertyAndUpgrade.TotalCount - 1);
            var simpleSystemProperty = new SimpleSystemProperty(upgradeProperty)
            {
                index = systemProperty.Index + 1
            };
            return simpleSystemProperty;
        }

        lockDetails = propertyAndUpgrade.GetLockDetails(systemProperty.Index + 1);
        return propertyAndUpgrade.GetPropertyAt(systemProperty.Index + 1);
    }

    // ReSharper disable once UnusedVariable
    public ISystemProperty GetUpgradeProperty(string groupId, string id) =>
        GetUpgradeProperty(groupId, id, out var lockDetails);

    public LockDetails GetLockDetailsForUpgrade(string groupId, string id)
    {
        GetUpgradeProperty(groupId, id, out var lockDetails);
        return lockDetails;
    }

    public void UpdateProperty(string ballGroupId, ISystemProperty property)
    {
        SetPropertiesToBallGroup(ballGroupId,
            GetPropertiesToBallGroup(ballGroupId)
                .Select(systemProperty => systemProperty.Id == property.Id ? property : systemProperty).ToList());
        PropertyUpgraded?.Invoke(ballGroupId, property);
    }

    private void Awake()
    {
        Instance = this;
        foreach (var groupAndProperty in GetGroupAndProperties())
        {
            if (!IsBallGroupLocked(groupAndProperty.Key))
                SetPropertiesToBallGroup(groupAndProperty.Key, groupAndProperty.Value);
        }
    }

    public void UnlockBallGroup(string groupId)
    {
        if (!IsBallGroupLocked(groupId))
        {
            return;
        }

        PrefManager.SetBool("IsLocked_" + groupId, false);
        UpdateProperty(groupId,
            GetPropertiesAndUpgrades(groupId).First(property => property.id == "Count").GetPropertyAt(0));
    }

    // ReSharper disable once UnusedVariable
    public bool IsBallGroupLocked(string groupId) => IsBallGroupLocked(groupId, out var lokDetails);

    public bool IsBallGroupLocked(string groupId, out LockDetails lockDetails)
    {
        var ball = ModelBalls.First(b => b.groupId == groupId);
        lockDetails = ball.lockDetails;

        return ball.preLocked && PrefManager.GetBool("IsLocked_" + ball.groupId, true);
    }
}