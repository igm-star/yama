﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoundColliders : MonoBehaviour
{
    [SerializeField]private List<Transform> _colliders = new List<Transform>();
    [SerializeField] private RectTransform _topTargetPoint,_bottomTargetPoint;
    [SerializeField] private float _colliderWidth;


    private IEnumerator Start()
    {
        yield return new WaitForEndOfFrame();
        var camera = Camera.main;
        var top = _colliders[0];
        // ReSharper disable once PossibleNullReferenceException
        top.transform.position = camera.ScreenToWorldPoint(_topTargetPoint.position) + Vector3.up * _colliderWidth/2f;

        var right = _colliders[1];
        right.transform.position = camera.ScreenToWorldPoint(new Vector3(Screen.width,Screen.height/2f))+Vector3.right*_colliderWidth/2f;

        var bottom = _colliders[2];
        bottom.transform.position = camera.ScreenToWorldPoint(_bottomTargetPoint.position) - Vector3.up * _colliderWidth / 2f; ;

        var left = _colliders[3];
        left.transform.position = camera.ScreenToWorldPoint(new Vector3(0, Screen.height / 2f)) - Vector3.right * _colliderWidth / 2f; 
    }
}
