﻿// /*
// Created by Darsan
// */

using UnityEngine;
using UnityEngine.EventSystems;

public class ShowOrPassAdsOnClick : MonoBehaviour,IPointerClickHandler
{
    public void OnPointerClick(PointerEventData eventData)
    {
        AdsManager.ShowOrPassAdsIfCan();
    }
}