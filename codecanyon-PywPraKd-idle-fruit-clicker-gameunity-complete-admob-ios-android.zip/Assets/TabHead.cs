﻿// /*
// Created by Darsan
// */

using System;
using UnityEngine;
using UnityEngine.UI;

public class TabHead : MonoBehaviour
{
    public event Action<TabHead> Clicked;
    
    [SerializeField] private TabPanel _tabPanel;
    [SerializeField]private Sprite[] _activeAndDeActiveSprites = new Sprite[2];

    private bool _active;

    public TabPanel TabPanel => _tabPanel;

    public bool Active
    {
        get => _active;
        set
        {
            _active = value;
            _tabPanel.Active = value;
            GetComponent<Image>().sprite = _activeAndDeActiveSprites[value ? 0 : 1];
        }
    }

    public void OnClick()
    {
        Clicked?.Invoke(this);
    }
}