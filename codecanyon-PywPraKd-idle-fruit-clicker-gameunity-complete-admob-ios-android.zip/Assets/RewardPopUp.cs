﻿// /*
// Created by Darsan
// */

using System;
using UnityEngine;
using UnityEngine.UI;

public class RewardPopUp : ShowHidable
{
    [SerializeField] private Text _moneyTxt;
    [SerializeField] private Button _looseBtn;
    [SerializeField] private GameObject _moneyBlashEffect;


    private int _money;

    public int Money
    {
        get => _money;
        private set
        {
            _money = value;
            _moneyTxt.text = value.ToString();
        }
    }

    public override void Show(bool animate = true, Action completed = null)
    {
        base.Show(animate, completed);
        Money = LevelManager.GetRewardAmount();
        _looseBtn.gameObject.SetActive(false);
        Invoke(nameof(ActivateLoose),2.5f);
    }

    private void ActivateLoose()
    {
        _looseBtn.gameObject.SetActive(true);
    }

    public void OnClickLoose()
    {
        Hide();
    }

    public void OnClickReward()
    {
        if (!AdsManager.IsVideoAvailable())
        {
            var popUpPanel = UIManager.Instance.PopUpPanel;
            popUpPanel.ShowAsInfo("No Ads", "Please turn on your internet connection!");
            return;
        }

        AdsManager.ShowVideoAds(true,success =>
        {
            if (success)
            {
                ResourceManager.Coins += Money;
                Instantiate(_moneyBlashEffect);
                Hide();
            }
        });
    }

}


