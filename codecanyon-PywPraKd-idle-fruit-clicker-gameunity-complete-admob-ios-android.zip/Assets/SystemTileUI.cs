﻿// /*
// Created by Darsan
// */

using System;
using UnityEngine;
using UnityEngine.UI;

public class SystemTileUI : SimpleBtn
{
    [SerializeField] private Text _titleTxt, _subTitleTxt, _priceTxt;
    [SerializeField] private GameObject _priceGroup, _watchVideoGroup;

    private ViewModel _mViewModel;
    private bool _useCoins;

    public ViewModel MViewModel
    {
        get => _mViewModel;
        set
        {
            _mViewModel = value;
            _titleTxt.text = value.Title;
            _subTitleTxt.text = value.SubTitle;
            if (value.LockDetails.useCoins)
                _priceTxt.text = value.LockDetails.unlockCoins.ToString();
            UseCoins = value.LockDetails.useCoins;
        }
    }

    public bool UseCoins
    {
        get => _useCoins;
        set
        {
            _priceGroup.SetActive(value);
            _watchVideoGroup.SetActive(!value);
            _useCoins = value;
        }
    }

    private void Update()
    {
        Intractable = !UseCoins || ResourceManager.Coins >= MViewModel.LockDetails.unlockCoins;
    }

    public struct ViewModel
    {
        public string Title => SystemProperty.Name;
        public string SubTitle { get; set; }
        public LockDetails LockDetails { get; set; }
        public ISystemProperty SystemProperty { get; set; }
    }
}

[RequireComponent(typeof(Button))]
public class SimpleBtn : MonoBehaviour
{
    public event Action<SimpleBtn> Clicked;

    [SerializeField] protected Sprite disableSprite;
    [SerializeField] protected Sprite normalSprite;


    private Button _btn;
    private bool _intractable;

    public bool Intractable
    {
        get => _intractable;
        set
        {
            _intractable = value;
            _btn.interactable = value;
            _btn.image.sprite = value ? normalSprite : disableSprite;
        }
    }

    protected virtual void Awake()
    {
        _btn = GetComponent<Button>();
        _btn.onClick.AddListener(() =>
        {
            OnClicked();
            Clicked?.Invoke(this);
        });
        Intractable = Intractable;
    }

    protected virtual void OnClicked()
    {
    }
}