﻿// /*
// Created by Darsan
// */

using System;
using System.Collections.Generic;
using Game;
using UnityEngine;
using UnityEngine.UI;

public partial class GamePlayPanel : MonoBehaviour
{
    [SerializeField] private List<TabHead> _tabHeads= new List<TabHead>();
    [SerializeField] private GameObject _levelProgressGroup, _levelCompleteBtn;
    [SerializeField] private Text _levelTxt;
    [SerializeField] private Slider _levelProgressSlider;
    [SerializeField] private RewardTile _rewardTile;
    [SerializeField] private RectTransform _rewardContainer;

    private TabHead _selectedTab;
    private float _timeLeftForReward;

    public LevelManager LevelManager=>LevelManager.Instance;

    public TabHead SelectedTab
    {
        get => _selectedTab;
        set
        {
            _selectedTab = value;
            foreach (var tabHead in _tabHeads)
            {
                tabHead.Active = value == tabHead;
            }
        }
    }

    private void Awake()
    {
        SelectedTab = _tabHeads[0];
        _tabHeads.ForEach(head => head.Clicked +=HeadOnClicked);
        _rewardTile.Clicked += RewardTileOnClicked;
    }

    private void Start()
    {
        _timeLeftForReward = LevelManager.GetRewardTimeInterval();
    }

    private void Update()
    {
        _timeLeftForReward -= Time.deltaTime;

        if (_timeLeftForReward <= 0 && !_rewardContainer.gameObject.activeSelf)
        {
            ShowReward();
        }

        _levelProgressGroup.SetActive(!LevelManager.CurrentLevelCompleted);
        _levelCompleteBtn.SetActive(LevelManager.CurrentLevelCompleted);
        _levelTxt.text = $"Level {LevelManager.CompletedLevel + 1}";
        if (!LevelManager.CurrentLevelCompleted)
            _levelProgressSlider.normalizedValue = LevelManager.LevelProgress;
    }

    private void RewardTileOnClicked(RewardTile tile)
    {
        CancelInvoke(nameof(HideReward));
        HideReward();
        UIManager.Instance.RewardPopUp.Show();
    }


    public void OnClickLevelUp()
    {
        var levelCompletePopUp = UIManager.Instance.LevelCompletePopUp;
        levelCompletePopUp.Level = LevelManager.CompletedLevel + 1;
        levelCompletePopUp.Show();
    }

    public void ShowReward()
    {
        if (!_rewardContainer.gameObject.activeSelf)
            _rewardContainer.gameObject.SetActive(true);

        CancelInvoke(nameof(HideReward));
        Invoke(nameof(HideReward), 180f);
    }

    public void HideReward()
    {
        if (!_rewardContainer.gameObject.activeSelf)
            return;
        _rewardContainer.gameObject.SetActive(false);
        _timeLeftForReward = LevelManager.GetRewardTimeInterval();
    }

    private void HeadOnClicked(TabHead head)
    {
        SelectedTab = head;
    }
}


public partial class GamePlayPanel : ITargetUIProvider
{
    [SerializeField] private TargetUI _targetUIPrefab;
    [SerializeField] private RectTransform _targetUIContent;


    public TargetUI GetTargetUI()
    {
        return Instantiate(_targetUIPrefab,_targetUIContent);
    }

    public void ReturnTargetUI(TargetUI ui)
    {
        Destroy(ui.gameObject);
    }
}

public enum BottomBarTab
{
    System,Fruits
}