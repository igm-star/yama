﻿// /*
// Created by Darsan
// */

using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Random = UnityEngine.Random;

namespace Game
{
    public class LevelEnvironment : MonoBehaviour
    {

        [SerializeField] private Vector2 _targetWidthAndHeight;

        private int _totalTargetHealth;
        public IEnumerable<Target> Targets => GetComponentsInChildren<Target>();

        public int TotalTargetHealth
        {
            get => _totalTargetHealth;
            set
            {
                var targets = Targets.ToList();
                var list = Split(value, targets.Count).GetRandom(targets.Count).ToList();
                for (var i = 0; i < list.Count; i++)
                {
                    targets[i].Health = list[i];
                }
                _totalTargetHealth = value;
            }
        }

        public ITargetUIProvider TargetUIProvider
        {
            set
            {
                Targets.ForEach(target => target.TargetUIProvider = value);
            }
        }

        public static IEnumerable<int> Split(int total, int count)
        {
            var avg = total/count;
            var elapsed = 0;

            for (var i = 0; i < count/2; i++)
            {
                var range = Random.Range(avg/4,avg+ 3*avg/4);
                elapsed += range;
                yield return range;

                if (i < count / 2 - 1 || count%2==1)
                {
                    var val = avg * 2 - range;
                    elapsed += val;
                    yield return val;
                }
                else
                {
                    yield return total - elapsed;
                    yield break;
                }
            }

            yield return total - elapsed;

        }

        private void OnDrawGizmos()
        {
            var bottomLeft = transform.position - (Vector3)_targetWidthAndHeight / 2f;
            var topRight = transform.position + (Vector3)_targetWidthAndHeight / 2f;

            Gizmos.color = Color.white;

            Gizmos.DrawLine(topRight,bottomLeft.WithY(topRight.y));
            Gizmos.DrawLine(bottomLeft.WithX(topRight.x),topRight);
            Gizmos.DrawLine(bottomLeft,topRight.WithY(bottomLeft.y));
            Gizmos.DrawLine(bottomLeft,topRight.WithX(bottomLeft.x));
        }
    }
}