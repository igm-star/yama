﻿// /*
// Created by Darsan
// */

using System;
using UnityEngine;
using UnityEngine.UI;

public class OfflineRewardsPopUp : ShowHidable
{
    [SerializeField] private Text _moneyTxt;
    [SerializeField] private Button _clamBtn;
    [SerializeField] private Text _lvlTxt;
    [SerializeField] private GameObject _moneyBlashEffect;


    private int _level;
    private int _money;

    public int Level
    {
        get => _level;
        set
        {
            _level = value;
            Money = LevelManager.GetRewardForLevel(value);
            _lvlTxt.text = $"Level {value}";
        }
    }

    public int Money
    {
        get => _money;
         set
        {
            _money = value;
            _moneyTxt.text = value.ToString();
        }
    }

    public override void Show(bool animate = true, Action completed = null)
    {
        base.Show(animate, completed);
        
        _clamBtn.gameObject.SetActive(false);
        Invoke(nameof(ActivateClam),2.5f);
    }

    private void ActivateClam()
    {
        _clamBtn.gameObject.SetActive(true);
    }

    public void OnClickClam()
    {
        ResourceManager.Coins += Money;
        Instantiate(_moneyBlashEffect);
        Hide();
    }

    public void OnClickReward()
    {
        if (!AdsManager.IsVideoAvailable())
        {
            var popUpPanel = UIManager.Instance.PopUpPanel;
            popUpPanel.ShowAsInfo("No Ads", "Please turn on your internet connection!");
            return;
        }

        AdsManager.ShowVideoAds(true,success =>
        {
            if (!success)
                return;

            ResourceManager.Coins += 3 * Money;
            Instantiate(_moneyBlashEffect);
            Hide();
        });
    }
}