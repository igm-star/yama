﻿// /*
// Created by Darsan
// */

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Random = UnityEngine.Random;

[Serializable]
public struct PropertyAndUpgrade
{
    public string id;
    public string name;
    public List<ValueAndLockDetails> valueAndLockDetailses;
    [SerializeField] private float _maxValue;
    [SerializeField] private bool _integerValue;

    public LockDetails GetLockDetails(int index)
    {
        if (index < valueAndLockDetailses.Count)
        {
            return valueAndLockDetailses[index].lockDetails;
        }
        else
        {
            var lockDetails = valueAndLockDetailses[valueAndLockDetailses.Count-1].lockDetails;
            if (index%5!=0)
            {
                var lastDis = lockDetails.unlockCoins -
                              valueAndLockDetailses[valueAndLockDetailses.Count - 2].lockDetails.unlockCoins;

                var currentLevelDis = index - (valueAndLockDetailses.Count - 1);
                //(1 - x ^ n) / (1 - x)
                var x = 1.2f;
                var n = 2 + (float)currentLevelDis / 3;
                var multiplexer = (1 - Mathf.Pow(x,n)) / (1 - x);

                var lastAdditions = Mathf.Pow(x, n - 1);

                lockDetails.unlockCoins +=
                    Mathf.RoundToInt((lastDis * multiplexer + (currentLevelDis % 3) * lastAdditions) / 100f) * 100;
            }
            else
            {
                lockDetails.hasVideoUnLock = true;
                lockDetails.useCoins = false;
            }

            return lockDetails;
        }
    }

    public int TotalCount => 100;

    public ISystemProperty GetPropertyAt(int index)
    {
        if (valueAndLockDetailses.Count > index)
        {
            return new SimpleSystemProperty
            {
                id = id,
                value = valueAndLockDetailses[index].value,
                index = index,
                name = name
            };
        }
        else
        {
            var totalDis = (_maxValue - valueAndLockDetailses[valueAndLockDetailses.Count - 1].value);
            var totalLevelDistance = 100 - valueAndLockDetailses.Count;
            var value = valueAndLockDetailses[valueAndLockDetailses.Count - 1].value +
                        Mathf.Min(valueAndLockDetailses[valueAndLockDetailses.Count - 1].value - valueAndLockDetailses[valueAndLockDetailses.Count - 2].value, totalDis / totalLevelDistance) * (index - (valueAndLockDetailses.Count - 1));
            return new SimpleSystemProperty
            {
                id = id,
                value = _integerValue?Mathf.RoundToInt(value) : value,
                index = index,
                name = name
            };
        }
    }

    [Serializable]
    public struct ValueAndLockDetails
    {
        public float value;
        public LockDetails lockDetails;
    }
}

[Serializable]
public struct PropertiesData : IEnumerable<SimpleSystemProperty>
{
    public List<SimpleSystemProperty> properties;

    public PropertiesData(IEnumerable<ISystemProperty> properties)
    {
        this.properties = properties.Select(property => new SimpleSystemProperty(property)).ToList();
    }

    public IEnumerator<SimpleSystemProperty> GetEnumerator()
    {
        return properties.GetEnumerator();
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
        return GetEnumerator();
    }
}


[Serializable]
public struct LockDetails
{
    public bool hasVideoUnLock;
    public bool useCoins;

    [ConditionalField(nameof(useCoins), true)]
    public int unlockCoins;
}

[Serializable]
public struct SimpleSystemProperty : ISystemProperty
{
    public string id;
    public string name;
    public int index;
    public float value;

    public string Id => id;
    public string Name => name;
    public int Index => index;
    public float Value => value;

    public SimpleSystemProperty(ISystemProperty property)
    {
        id = property.Id;
        name = property.Name;
        index = property.Index;
        value = property.Value;
    }
}

public interface ISystemProperty
{
    string Id { get; }
    string Name { get; }
    int Index { get; }
    float Value { get; }
}