﻿using System;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Button))]
public class CoinsMultiplexerButton : MonoBehaviour
{
    [SerializeField] private Text _timerTxt;
    [SerializeField] private GameObject _rewardEffect;

    private Button _button;


    private void Awake()
    {
        _button = GetComponent<Button>();
        _button.onClick.AddListener(OnClick);
    }

    private void OnClick()
    {
        var popUpPanel = UIManager.Instance.PopUpPanel;
        popUpPanel.ShowAsConfirmation("2x Earning",
            $"Watch Video to active 2x earnings for {LevelManager.EARNINGS_MULTIPLEXER_OFFER_TIME} seconds",
            success =>
            {
                if (!success)
                    return;

                if (!AdsManager.IsVideoAvailable())
                {
                    popUpPanel.ShowAsInfo("No Ads", "Please turn on your internet connection!");
                    return;
                }

                AdsManager.ShowVideoAds(true, s =>
                {
                    if (s)
                        LevelManager.ActivateEarningsMultiplexer();
                });
            });

        Refresh();
    }

    private void Refresh()
    {
        _rewardEffect.SetActive(LevelManager.EarningMultiplexerOfferActive);
        _timerTxt.gameObject.SetActive(LevelManager.EarningMultiplexerOfferActive);
        _timerTxt.text = ToTimeString(LevelManager.TimeLeftToEarningMultiplexerEnd);
        _button.interactable = !LevelManager.EarningMultiplexerOfferActive;
    }

    private static string ToTimeString(float time)
    {
        if (time >= 3600)
            throw new NotImplementedException();
        var t = Mathf.FloorToInt(time);
        return (t / 60).ToString("00") + ":" + (t % 60).ToString("00");
    }


    // Update is called once per frame
    void Update()
    {
        Refresh();
    }
}