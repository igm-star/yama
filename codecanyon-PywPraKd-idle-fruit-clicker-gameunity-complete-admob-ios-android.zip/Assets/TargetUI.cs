﻿// /*
// Created by Darsan
// */

using System;
using UnityEngine;

namespace Game
{
    public class TargetUI : MonoBehaviour
    {

        [SerializeField] private NumberText _numberTxt;

        private Camera _camera;

        public int HealthPoints
        {
            get => _numberTxt.Value;
            set => _numberTxt.Value= value;
        }

        public Target Target { get; set; }

        public Camera Camera =>_camera==null ?  _camera = Camera.main:_camera;

        private void Update()
        {
            if(Target==null)
                return;

            transform.position = Camera.WorldToScreenPoint(Target.transform.position);
        }
    }
}