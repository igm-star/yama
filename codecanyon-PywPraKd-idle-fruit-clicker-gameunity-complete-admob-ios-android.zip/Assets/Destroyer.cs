﻿// /*
// Created by Darsan
// */

using System;
using UnityEngine;

public class Destroyer : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D other)
    {
        var go = other.attachedRigidbody!=null ?other.attachedRigidbody.gameObject : other.gameObject;
        Destroy(go);
    }
}