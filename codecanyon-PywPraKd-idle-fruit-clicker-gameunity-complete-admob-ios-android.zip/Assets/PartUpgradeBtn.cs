﻿// /*
// Created by Darsan
// */

using System;
using UnityEngine;
using UnityEngine.UI;

public class PartUpgradeBtn : SimpleBtn
{
    [SerializeField] private Text _titleTxt, _lvlTxt, _priceTxt,_valueTxt;
    [SerializeField] private GameObject _priceGroup, _watchVideoGroup;

    private ViewModel _mViewModel;
    private bool _useCoins;

    public ViewModel MViewModel
    {
        get => _mViewModel;
        set
        {
            if (value.SystemProperty == null)
            {
                gameObject.SetActive(false);
                return;
            }

            _mViewModel = value;
            _titleTxt.text = value.Title;
            _lvlTxt.text = $"Level {value.Level}";
            _valueTxt.text = Math.Abs(value.Value - Mathf.RoundToInt(value.Value)) < float.Epsilon
                ? Mathf.RoundToInt(value.Value).ToString()
                : value.Value.ToString("F1");
            if (value.LockDetails.useCoins)
                _priceTxt.text = value.LockDetails.unlockCoins.ToString();
            UseCoins = value.LockDetails.useCoins;
        }
    }

    public bool UseCoins
    {
        get => _useCoins;
        set
        {
            _priceGroup.SetActive(value);
            _watchVideoGroup.SetActive(!value);
            _useCoins = value;
        }
    }

    private void Update()
    {
        Intractable = !UseCoins || ResourceManager.Coins >= MViewModel.LockDetails.unlockCoins;
    }

    public struct ViewModel
    {
        public string Title => SystemProperty.Name;
        public int Level => SystemProperty.Index;
        public LockDetails LockDetails { get; set; }
        public ISystemProperty SystemProperty { get; set; }
        public float Value { get; set; }
    }
}