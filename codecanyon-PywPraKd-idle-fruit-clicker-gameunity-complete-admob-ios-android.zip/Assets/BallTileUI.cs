﻿// /*
// Created by Darsan
// */

using System;
using System.Linq;
using Model;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class BallTileUI : MonoBehaviour,IPointerClickHandler
{
    public event Action<BallTileUI> Clicked;
    
    [SerializeField] private Image _img;
    [SerializeField] private GameObject _priceGroup, _watchVideoGroup;
    [SerializeField] private GameObject _highlightGroup;
    [SerializeField] private CanvasGroup _canvasGroup;

    private ViewModel _mViewModel;
    private bool _intractable;
    private bool _highlighting;

    public ViewModel MViewModel
    {
        get => _mViewModel;
        set
        {
            _img.sprite = value.Ball.icon;
            _mViewModel = value;

            _priceGroup.SetActive(value.Locked && value.Ball.lockDetails.useCoins);
            _watchVideoGroup.SetActive(value.Locked && value.Ball.lockDetails.hasVideoUnLock);

            if (value.Locked && value.Ball.lockDetails.useCoins)
                _priceGroup.GetComponentInChildren<NumberText>().Value= value.Ball.lockDetails.unlockCoins;
        }
    }

    public bool Highlighting
    {
        get => _highlighting;
        set
        {
            _highlighting = value;
            _highlightGroup.SetActive(value);
        }
    }

    public bool Intractable
    {
        get => _intractable;
        set
        {
            _intractable = value;
            _canvasGroup.alpha = value ? 1 : 0.4f;
        }
    }

    public BallSystem BallSystem =>BallSystem.Instance;

   
    private void Update()
    {
        if(string.IsNullOrEmpty(MViewModel.Ball.groupId))
            return;

        Intractable = !MViewModel.Locked || ResourceManager.Coins >= MViewModel.Ball.lockDetails.unlockCoins ||
                      MViewModel.Ball.lockDetails.hasVideoUnLock;

        Highlighting = !MViewModel.Locked && BallSystem.GetPropertiesToBallGroup(MViewModel.Ball.groupId).Any(property =>
        {
            var lockDetails = BallSystem.GetLockDetailsForUpgrade(MViewModel.Ball.groupId, property.Id);

            return lockDetails.useCoins && ResourceManager.Coins >= lockDetails.unlockCoins ||
                   lockDetails.hasVideoUnLock;
        });
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        Clicked?.Invoke(this);
    }


    public struct ViewModel
    {
        public Ball Ball { get; set; }
        public bool Locked { get; set; }
    }
}