﻿// /*
// Created by Darsan
// */
using System;
using System.Collections.Generic;
using System.Linq;
using Game;
using UnityEngine;

public partial class LevelManager : MonoBehaviour
{
    public static event Action<Target> TargetClicked;
    public static event Action<Target,int,Vector2> EarnedCoinsByTargetDamage; 
    public static LevelManager Instance { get; private set; }


    [SerializeField] private BallSystem _ballSystem;
    [SerializeField]private List<LevelEnvironment> _levelEnvironments = new List<LevelEnvironment>();
    [SerializeField]private List<int> _targetTotalHealthForLevels = new List<int>();

    public BallSystem BallSystem => _ballSystem;

    public static int CompletedLevel
    {
        get => PrefManager.GetInt(nameof(CompletedLevel));
        private set => PrefManager.SetInt(nameof(CompletedLevel),value);
    }

    public LevelEnvironment CurrentLevelEnvironment { get; private set; }
    public int TargetHealth { get; private set; }
    public int CollectedHealth { get; private set; }
    public float LevelProgress => (float)CollectedHealth / TargetHealth;

    private void Awake()
    {
        Instance = this;
        
    }

    private void Start()
    {
        LoadLevel();
    }


    public void CompleteLevel()
    {
        if(LevelProgress<1)
            return;

        CompletedLevel++;
        CollectedHealth = 0;

        LoadLevel();
    }

    private void LoadLevel()
    {
        if(CurrentLevelEnvironment!=null)
            Destroy(CurrentLevelEnvironment.gameObject);

        CurrentLevelEnvironment = Instantiate(_levelEnvironments.Count > CompletedLevel?_levelEnvironments[CompletedLevel]:_levelEnvironments.GetRandom());
        var targetHealth = GetTotalTargetHealthForLevel(CompletedLevel + 1);
        CurrentLevelEnvironment.TargetUIProvider = UIManager.Instance!=null ? UIManager.Instance.GamePlayPanel : null;
        CurrentLevelEnvironment.TotalTargetHealth = targetHealth;
        TargetHealth = targetHealth;
        CollectedHealth = 0;
        foreach (var target in CurrentLevelEnvironment.Targets)
        {
            target.Damaged +=TargetOnDamaged;
            target.Clicked +=TargetOnClicked;
        }
    }

    private void TargetOnClicked(Target target)
    {
        // ReSharper disable once PossibleNullReferenceException
        target.Hit(TapEarning,Camera.main.ScreenToWorldPoint(Input.mousePosition));
        TargetClicked?.Invoke(target);
    }

    private void TargetOnDamaged(Target target, int dmg, Vector2 point)
    {
        CollectedHealth += dmg;
        var coins = Mathf.RoundToInt(CurrentTotalEarningsMultiplexer * dmg);
        ResourceManager.Coins += coins;
        EarnedCoinsByTargetDamage?.Invoke(target,coins,point);
    }

    private int GetTotalTargetHealthForLevel(int lvl)
    {
        if (_targetTotalHealthForLevels.Count>=lvl)
        {
            return _targetTotalHealthForLevels[lvl - 1];
        }

        if (_targetTotalHealthForLevels.Count <= 1)
            return 10000;

        var lastDistance = _targetTotalHealthForLevels.Last() - _targetTotalHealthForLevels[_targetTotalHealthForLevels.Count-2];
        return _targetTotalHealthForLevels.Last() +
               (int) (Mathf.Pow(1.25f, lvl - _targetTotalHealthForLevels.Count) * lastDistance);
    }
}

public partial class LevelManager 
{
    public const float SPEED_MULTIPLEXER_OFFER_TIME = 40f;
    public const float EARNINGS_MULTIPLEXER_OFFER_TIME = 120f;

    public static float CurrentTotalSpeedMultiplexer => SpeedMultiplexer * (SpeedMultiplexerOfferActive ? 2 : 1f);

    public static float CurrentTotalEarningsMultiplexer =>
        EarningsMultiplexer * (EarningMultiplexerOfferActive ? 2f : 1f);

    public static bool SpeedMultiplexerOfferActive { get; private set; }
    public static bool EarningMultiplexerOfferActive { get; private set; }

    public static float TimeLeftToSpeedMultiplexerEnd { get; private set; }
    public static float TimeLeftToEarningMultiplexerEnd { get; private set; }

    public static float SpeedMultiplexer =>
        Properties.First(property => property.Id == nameof(SpeedMultiplexer)).Value;

    public static float EarningsMultiplexer =>
        Properties.First(property => property.Id == nameof(EarningsMultiplexer)).Value;

    public static int TapEarning => (int)Properties.First(property => property.Id == nameof(TapEarning)).Value;


    private void Update()
    {
        if (SpeedMultiplexerOfferActive)
        {
            TimeLeftToSpeedMultiplexerEnd =
                Mathf.Clamp(TimeLeftToSpeedMultiplexerEnd - Time.deltaTime, 0f, Mathf.Infinity);
            if (TimeLeftToSpeedMultiplexerEnd <= 0)
                SpeedMultiplexerOfferActive = false;
        }

        if (EarningMultiplexerOfferActive)
        {
            TimeLeftToEarningMultiplexerEnd =
                Mathf.Clamp(TimeLeftToEarningMultiplexerEnd - Time.deltaTime, 0f, Mathf.Infinity);
            if (TimeLeftToEarningMultiplexerEnd <= 0)
                EarningMultiplexerOfferActive = false;
        }

        Time.timeScale = CurrentTotalSpeedMultiplexer;
    }


    public static void ActivateSpeedMultiplexer()
    {
        SpeedMultiplexerOfferActive = true;
        TimeLeftToSpeedMultiplexerEnd = SPEED_MULTIPLEXER_OFFER_TIME;
    }

    public static void ActivateEarningsMultiplexer()
    {
        EarningMultiplexerOfferActive = true;
        TimeLeftToEarningMultiplexerEnd = EARNINGS_MULTIPLEXER_OFFER_TIME;
    }
}

public partial class LevelManager
{

    public bool CurrentLevelCompleted => LevelProgress >= 1f;

    public static int GetRewardForLevel(int level)
    {
        if (CompletedLevel < 5)
            return ((500 * (CompletedLevel + 1))/2).FloorTo(2);
        if (CompletedLevel < 8)
            return ((2500 + (CompletedLevel - 5 + 1) * 1000)/2).FloorTo(2);

        if (CompletedLevel < 12)
            return ((2500 + (CompletedLevel - 5 + 1) * 3000)/2).FloorTo(2);

        if (CompletedLevel < 15)
            return ((2500 + (CompletedLevel - 5 + 1) * 5000)/2).FloorTo(2);

        return ((2500 + (CompletedLevel - 5 + 1) * 7000)/2).FloorTo(2);
    }




    public static int GetRewardAmount()
    {
        if (CompletedLevel < 5)
            return ((3000 * (CompletedLevel + 1))/2).FloorTo(2);
        if (CompletedLevel < 8)
            return ((15000 + (CompletedLevel - 5 + 1) * 6000)/2).FloorTo(2);

        if (CompletedLevel < 12)
            return ((15000 + (CompletedLevel - 5 + 1) * 8000)/2).FloorTo(2);

        if (CompletedLevel < 15)
            return ((15000 + (CompletedLevel - 5 + 1) * 10000)/2).FloorTo(2);

        return ((15000 + (CompletedLevel - 5 + 1) * 12000)/2).FloorTo(2);
    }

    public static int GetRewardTimeInterval()
    {
        if (CompletedLevel == 0)
            return 70;

        return 40;
    }

    public static int GetOfflineRewards(float seconds)
    {
        Debug.Log($"Seconds = {seconds}");
        var maxReward = Mathf.Clamp(500 + Mathf.Pow(CompletedLevel + 1, 1.5f) * 800, 0, 100000);


        if (seconds < 600)
        {
            var roundToInt = Mathf.RoundToInt(Mathf.Lerp(1, (maxReward / 200f), seconds / 600f));
            return roundToInt * 100;
        }

        return Mathf.RoundToInt(Mathf.Lerp(maxReward / 200f, maxReward / 100f, Mathf.Clamp01(seconds / 1800))) * 100;
    }
}

public partial class LevelManager
{
    public static event Action<ISystemProperty> PropertyUpgraded;

    [SerializeField] private List<PropertyAndUpgrade> _propertiesAndUpgrades = new List<PropertyAndUpgrade>();


    public IEnumerable<PropertyAndUpgrade> PropertiesAndUpgrades => _propertiesAndUpgrades;

    protected readonly List<ISystemProperty> properties = new List<ISystemProperty>();

    public static IEnumerable<ISystemProperty> Properties
    {
        get
        {
            if (Instance.properties.Count == 0)
            {
                var json = PrefManager.GetString("SystemProperties",
                    JsonUtility.ToJson(new PropertiesData(Instance.GetInitialProperties())));
                //                Debug.Log(json);
                var systemProperties = JsonUtility.FromJson<PropertiesData>
                    (json).Select(property => (ISystemProperty)property);
                Instance.properties.AddRange(systemProperties);
            }

            return Instance.properties;
        }

        protected set
        {
            Instance.properties.Clear();
            Instance.properties.AddRange(value);
            PrefManager.SetString("SystemProperties",
                JsonUtility.ToJson(new PropertiesData(value)));
        }
    }


    private IEnumerable<ISystemProperty> GetInitialProperties()
    {
        return _propertiesAndUpgrades.Select(upgrade => upgrade.GetPropertyAt(0));
    }

    public static ISystemProperty GetUpgradeProperty(string id, out LockDetails lockDetails)
    {
        var systemProperty = Properties.FirstOrDefault(property => property.Id == id);

        if (systemProperty == null)
            throw new Exception(id);

        var propertyAndUpgrade = Instance._propertiesAndUpgrades.FirstOrDefault(upgrade => upgrade.id == id);
        if (string.IsNullOrEmpty(propertyAndUpgrade.id))
            throw new Exception();

        //Fake for upper limit
        if (systemProperty.Index >= propertyAndUpgrade.TotalCount - 1)
        {
            lockDetails = propertyAndUpgrade.GetLockDetails(propertyAndUpgrade.TotalCount - 1);

            if (lockDetails.useCoins && systemProperty.Index % 5 != 0)
            {
                lockDetails.unlockCoins = lockDetails.unlockCoins +
                                          Mathf.RoundToInt((systemProperty.Index + 2 - (propertyAndUpgrade.TotalCount - 1)) * lockDetails.unlockCoins * 0.3f);
            }
            else
            {
                lockDetails.useCoins = false;
                lockDetails.hasVideoUnLock = true;
            }

            var upgradeProperty = propertyAndUpgrade.GetPropertyAt(propertyAndUpgrade.TotalCount - 1);
            var simpleSystemProperty = new SimpleSystemProperty(upgradeProperty)
            {
                index = systemProperty.Index + 1
            };
            return simpleSystemProperty;
        }

        lockDetails = propertyAndUpgrade.GetLockDetails(systemProperty.Index + 1);
        return propertyAndUpgrade.GetPropertyAt(systemProperty.Index + 1);
    }

    // ReSharper disable once UnusedVariable
    public static ISystemProperty GetUpgradeProperty(string id) => GetUpgradeProperty(id, out var lockDetails);

    public static LockDetails GetLockDetailsForUpgrade(string id)
    {
        GetUpgradeProperty(id, out var lockDetails);
        return lockDetails;
    }

    public static void UpdateProperty(ISystemProperty property)
    {
        Properties = Properties.Select(systemProperty => systemProperty.Id == property.Id ? property : systemProperty)
            .ToList();

        PropertyUpgraded?.Invoke(property);
    }
}