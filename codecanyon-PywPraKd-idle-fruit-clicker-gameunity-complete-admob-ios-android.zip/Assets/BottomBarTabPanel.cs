﻿// /*
// Created by Darsan
// */

using UnityEngine;

public abstract class BottomBarTabPanel : TabPanel
{
    public abstract BottomBarTab Tab { get; }
}

public class TabPanel : MonoBehaviour
{
    public bool Active
    {
        get => gameObject.activeSelf;
        set => gameObject.SetActive(value);
    }
}