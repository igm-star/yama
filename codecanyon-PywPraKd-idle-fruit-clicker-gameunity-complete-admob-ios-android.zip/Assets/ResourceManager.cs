﻿// /*
// Created by Darsan
// */

using System;

public class ResourceManager : Singleton<ResourceManager>
{
    public static event Action<int> CoinsChanged; 

    public static int Coins
    {
        get => PrefManager.GetInt(nameof(Coins));
        set
        {
            PrefManager.SetInt(nameof(Coins), value);
            CoinsChanged?.Invoke(value);
        }
    }

    public static bool EnableAds
    {
        get => PrefManager.GetBool(nameof(EnableAds),true);
        set => PrefManager.SetBool(nameof(EnableAds),value);
    }
}