﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScaleAnimation : MonoBehaviour
{
    [SerializeField]private Vector2 _minAndMaxScales = new Vector2(1,1.1f);
    [SerializeField] private float _speed=1;
    [SerializeField] private AnimationCurve _curve;

    private float _targetScale;

    // Start is called before the first frame update
    void Start()
    {
        _targetScale = _minAndMaxScales.y;
    }

    // Update is called once per frame
    void Update()
    {
        var speed = _curve.Evaluate(Mathf.InverseLerp(_minAndMaxScales.x, _minAndMaxScales.y, transform.localScale.x)) *
                    _speed;
        transform.localScale =
            Vector3.one * Mathf.MoveTowards(transform.localScale.x, _targetScale, speed * Time.deltaTime);

        if (Mathf.Abs(transform.localScale.x - _targetScale) < 0.001f)
            _targetScale = _targetScale < _minAndMaxScales.y ? _minAndMaxScales.y : _minAndMaxScales.x;

    }
}
