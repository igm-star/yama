﻿// /*
// Created by Darsan
// */

using System;
using UnityEngine;

public class RotateAnim : MonoBehaviour
{
    [SerializeField] private float _speed = 30f;

    private void Update()
    {
        transform.rotation = Quaternion.AngleAxis(Time.deltaTime * _speed, Vector3.forward) * transform.rotation;
    }
}