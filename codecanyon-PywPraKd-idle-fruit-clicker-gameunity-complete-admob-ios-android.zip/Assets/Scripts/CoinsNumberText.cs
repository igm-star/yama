﻿// /*
// Created by Darsan
// */

using System;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(NumberText))]
public class CoinsNumberText : MonoBehaviour
{

    [SerializeField] private int _maxInstanceUpdateCoinsChange = 1;
    [SerializeField] private float _coinChangeTime = 0.5f;

    private NumberText _text;
    private float _coins;
    private float _coinsChangeSpeed;

    private float Coins
    {
        get => _coins;
        set
        {
            _text.Value = Mathf.RoundToInt(value);
            _coins = value;
        }
    }

    private void Awake()
    {
        _text = GetComponent<NumberText>();
    }

    private void OnEnable()
    {
        //_text = GetComponent<Text>();
        Coins = ResourceManager.Coins;
        ResourceManager.CoinsChanged += ResourceManagerOnCoinChanged;
    }

    private void ResourceManagerOnCoinChanged(int i)
    {
        var change = Mathf.Abs(ResourceManager.Coins - Coins);
        if (change <= _maxInstanceUpdateCoinsChange)
        {
            _coinsChangeSpeed = 100000;
        }
        else
        {
            _coinsChangeSpeed = change / _coinChangeTime;
        }
    }

    private void OnDestroy()
    {
        ResourceManager.CoinsChanged -= ResourceManagerOnCoinChanged;
    }

    private void Update()
    {
        if (Math.Abs(ResourceManager.Coins - Coins) > float.Epsilon)
        {
            Coins = Mathf.MoveTowards(Coins, ResourceManager.Coins, _coinsChangeSpeed * Time.deltaTime);
        }
    }
}