﻿public enum ShowState
{
    ShowAnimation, Show, HideAnimation, Hide
}