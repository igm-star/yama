﻿using System.Collections.Generic;
using UnityEngine;

namespace Model
{
    [System.Serializable]
    public struct Ball
    {
        public string groupId;
        public Game.Ball ballPrefab;
        public Sprite icon;
        public bool preLocked;
        public LockDetails lockDetails;
        public IEnumerable<PropertyAndUpgrade> PropertiesAndUpgrades => ballPrefab.PropertiesAndUpgrades;
    }
}