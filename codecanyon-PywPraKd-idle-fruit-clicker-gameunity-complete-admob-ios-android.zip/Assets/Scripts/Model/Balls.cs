﻿// /*
// Created by Darsan
// */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Model
{

    public class Balls : ScriptableObject,IEnumerable<Ball>
    {
        public static Balls Default => Resources.Load<Balls>(nameof(Balls));

        [SerializeField]private List<Ball> _balls = new List<Ball>();

        public IEnumerator<Ball> GetEnumerator() => _balls.GetEnumerator();

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

#if UNITY_EDITOR
        [UnityEditor.MenuItem("MyGames/Balls")]
        public static void Open()
        {
            GamePlayEditorManager.OpenScriptableAtDefault<Balls>();
        }
#endif
    }
}