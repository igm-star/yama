﻿using UnityEngine;

public class SharedUIManager : Singleton<SharedUIManager>
{


    [SerializeField] private ConsentPanel _consentPanel;


    public static ConsentPanel ConsentPanel => Instance._consentPanel;

}