﻿using UnityEngine;

[RequireComponent(typeof(Camera))]
public class AutoCameraSizer : MonoBehaviour, IInilizable
{

    [Range(0,1f)]
    [SerializeField] private float _widthVsHeight;
    [SerializeField] private Vector2 _targetWidthAndHeight;

    private Camera _camera;


    public bool Initialized { get; private set; }

    public void Init()
    {
        if (Initialized)
        {
            return;
        }

        _camera = GetComponent<Camera>();

        var aspect = (float)Screen.width / Screen.height;

        var widthAtTargetHeight = aspect * _targetWidthAndHeight.y;

        var width = Mathf.Lerp(_targetWidthAndHeight.x, widthAtTargetHeight, _widthVsHeight);
        var height = width / aspect;
        _camera.orthographicSize = height / 2;
        Initialized = true;
    }

    private void Awake()
    {
        Init();
    }

}


public interface IInilizable
{
    bool Initialized { get; }
    void Init();
}