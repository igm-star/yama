﻿// /*
// Created by Darsan
// */

using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Text))]
public class NumberText : MonoBehaviour
{

    [SerializeField] private int _maxLength = -1;

    private Text _text;
    private int _value;

    public int Value
    {
        get => _value;
        set
        {
            _value = value;

            if (_maxLength < 0)
            {
                Text.text = value.ToString();
                return;
            }

            var str = value.ToString();
            if (str.Length>_maxLength)
            {
                var extra = str.Length - _maxLength+1;

                if (extra > 9)
                {
                    Text.text = (value / 1000000000000f).ToString("F1")+"T";
                }
                else if (extra > 6)
                {
                    Text.text = (value / 1000000000f).ToString("F1")+"B";
                }
                else if (extra > 3)
                {
                    Text.text = (value / 1000000f).ToString("F1")+"M";
                }
                else if (extra > 0)
                {
                    Text.text = (value / 1000f).ToString("F1")+"k";
                }
                
            }
            else
            {
                Text.text = str;
            }
        }
    }

    public Text Text => _text == null ? _text = GetComponent<Text>() : _text;
}