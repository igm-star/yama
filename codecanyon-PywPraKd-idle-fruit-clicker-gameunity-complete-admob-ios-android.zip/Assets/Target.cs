﻿// /*
// Created by Darsan
// */

using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

namespace Game
{
    public class Target : MonoBehaviour
    {
        public event Action<Target> Clicked;
        public event Action<Target, int,Vector2> Damaged;
        public event Action<Target> Died;

        private static readonly int HitHash = Animator.StringToHash("Hit");


        [SerializeField] private List<Color> _colors = new List<Color>();
        [SerializeField] private SpriteRenderer _sprite;
        [SerializeField] private GameObject _dieParticlePrefab;
        [SerializeField] private Animator _anim;

        private int _health;
        private TargetUI _targetUI;
       

        public int Health
        {
            get => _health;
            set
            {
                _health = value;
                _sprite.color = GetColorForNumber(value);
                if (TargetUI != null)
                    TargetUI.HealthPoints = value;
            }
        }

        public ITargetUIProvider TargetUIProvider { get; set; }

        public TargetUI TargetUI
        {
            get
            {
                if (_targetUI == null)
                {
                    _targetUI = TargetUIProvider.GetTargetUI();
                    _targetUI.Target = this;
                }

                return _targetUI;
            }
        }

        public int Hit(Ball ball,Vector2 point)
        {
            return Hit(ball.Earning,point);
        }

        public int Hit(int damage,Vector2 point)
        {
            var realDamage = Mathf.Min(damage, Health);
            Health -= realDamage;

            Damaged?.Invoke(this, realDamage,point);
            if (Health <= 0)
            {
                Die();
            }
            else
            {
                _anim.SetTrigger(HitHash);
            }

            return realDamage;
        }

        private void Start()
        {
            Health = Health;
        }

        private void Die()
        {
            TargetUIProvider.ReturnTargetUI(TargetUI);
            Instantiate(_dieParticlePrefab, transform.position, Quaternion.identity);
            Died?.Invoke(this);
            Destroy(gameObject);
        }

        public Color GetColorForNumber(int number)
        {
            if (number <= 10)
                return Color.Lerp(_colors[0], _colors[1], number / 10f);
            if (number <= 100)
                return Color.Lerp(_colors[1], _colors[2], (number - 10) / 90f);
            if (number <= 500)
                return Color.Lerp(_colors[2], _colors[3], (number - 100) / 400f);
            if (number <= 5000)
                return Color.Lerp(_colors[3], _colors[4], (number - 500) / 4500f);
            if (number <= 15000)
                return Color.Lerp(_colors[4], _colors[5], (number - 5000) / 1000f);
            if (number <= 30000)
                return Color.Lerp(_colors[5], _colors[6], (number - 15000) / 15000f);


            return GetColorForNumber(number % 30000);
        }

        private void OnMouseDown()
        {

            if (
#if (UNITY_ANDROID || UNITY_IOS) && !UNITY_EDITOR
           EventSystem.current.IsPointerOverGameObject(Input.GetTouch(0).fingerId)
#else
                EventSystem.current.IsPointerOverGameObject()
#endif
            )
                return;
            Clicked?.Invoke(this);
            Debug.Log(nameof(OnMouseDown));

        }
    }

    public interface ITargetUIProvider
    {
        TargetUI GetTargetUI();
        void ReturnTargetUI(TargetUI ui);
    }
}