﻿using UnityEngine;
using UnityEngine.UI;

public class MoneyUIEffect : MonoBehaviour
{
    [SerializeField] private Text _text;
    [SerializeField] private bool _earn;
    private int _money;

    public bool Earn
    {
        get => _earn;
        set
        {
            _text.text = (value ? "+" : "-") + $"{Money}";
            _text.color = value ? Color.white : Color.red;
            _earn = value;
        }
    }

    public int Money
    {
        get => _money;
        set
        {
            _money = value;
            _text.text = (Earn ? "+" : "-") + $"{value}";
        }
    }
}
