﻿using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;

namespace Game
{
    [RequireComponent(typeof(Rigidbody2D))]
    public partial class Ball : MonoBehaviour
    {
        [SerializeField] private string _groupId;
        [SerializeField] private float _speed = 5;
        [SerializeField] private List<PropertyAndUpgrade> _propertiesAndUpgrades = new List<PropertyAndUpgrade>();


        public string GroupId => _groupId;

        private Rigidbody2D _rigid;

        public float Speed
        {
            get => _speed;
            set => _speed = value;
        }


        public int Earning { get; set; }
        public IEnumerable<PropertyAndUpgrade> PropertiesAndUpgrades => _propertiesAndUpgrades;


        private void Awake()
        {
            _rigid = GetComponent<Rigidbody2D>();
            _rigid.velocity = Random.insideUnitCircle * _speed;
            _rigid.angularVelocity = Random.Range(-400f, 400f);

        }


        private void FixedUpdate()
        {
            _rigid.velocity = _rigid.velocity.normalized * _speed;
        }


        private void OnCollisionEnter2D(Collision2D other)
        {
            if (other.gameObject.layer == (int) Layer.Target)
            {
                var target = other.gameObject.GetComponent<Target>();
                target.Hit(this,other.GetContact(0).point);
            }
            //Avoid Low,Max Angle collision
            CheckAndCorrectVelocityWhenCollision(other);
        }

        private void CheckAndCorrectVelocityWhenCollision(Collision2D other)
        {
            var contact = other.GetContact(0);
            if (Vector2.Angle(contact.normal, _rigid.velocity) < 15)
            {
                var angle = Random.Range(15f, 20f);

                _rigid.velocity =
                    _rigid.velocity.magnitude *
                    (Quaternion.AngleAxis(Vector3.Cross(contact.normal, _rigid.velocity).z > 0 ? angle : -angle,
                         Vector3.forward) *
                     contact.normal);
            }
            else if (Vector2.Angle(contact.normal, _rigid.velocity) > 85)
            {
                var angle = Random.Range(70f, 85f);

                _rigid.velocity =
                    _rigid.velocity.magnitude *
                    (Quaternion.AngleAxis(Vector3.Cross(contact.normal, _rigid.velocity).z > 0 ? angle : -angle,
                         Vector3.forward) *
                     contact.normal);
            }

            _rigid.angularVelocity = Random.Range(-400f, 400f);
            _rigid.velocity = Quaternion.AngleAxis(Random.Range(-5f, 5f), Vector3.forward) * _rigid.velocity;
        }
    }

    public partial class Ball
    {
        [SerializeField] private float _coinMultiplexer;
        [SerializeField] private float _earningMultiplexer;

        [ContextMenu(nameof(ApplyDataModifications))]
        public void ApplyDataModifications()
        {
            if(_coinMultiplexer<=0 || _earningMultiplexer<=0)
                return;

            foreach (var propertiesAndUpgrade in _propertiesAndUpgrades)
            {
                if (propertiesAndUpgrade.id == "Earning")
                {
                    for (var j = 0; j < propertiesAndUpgrade.valueAndLockDetailses.Count; j++)
                    {
                        var valueAndLockDetails = propertiesAndUpgrade.valueAndLockDetailses[j];
                        valueAndLockDetails.value = Mathf.RoundToInt(valueAndLockDetails.value*_earningMultiplexer);
                        propertiesAndUpgrade.valueAndLockDetailses[j] = valueAndLockDetails;
                    }
                }

                for (var i = 0; i < propertiesAndUpgrade.valueAndLockDetailses.Count; i++)
                {
                    var valueAndLockDetails = propertiesAndUpgrade.valueAndLockDetailses[i];
                    var lockDetails = valueAndLockDetails.lockDetails;
                    if (lockDetails.useCoins)
                    {
                        lockDetails.unlockCoins = Mathf.RoundToInt(lockDetails.unlockCoins*_coinMultiplexer).FloorTo(2);
                        valueAndLockDetails.lockDetails = lockDetails;
                        propertiesAndUpgrade.valueAndLockDetailses[i] = valueAndLockDetails;
                    }
                }
            }
#if UNITY_EDITOR
            UnityEditor.EditorUtility.SetDirty(this);
#endif
        }
    }
}


public enum Layer
{
    Target=8
}