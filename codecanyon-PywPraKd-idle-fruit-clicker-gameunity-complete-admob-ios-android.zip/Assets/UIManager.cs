﻿// /*
// Created by Darsan
// */

using System;
using UnityEngine;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance { get; private set; }

    [SerializeField] private GamePlayPanel _gamePlayPanel;
    [SerializeField] private PopUpPanel _popUpPanel;
    [SerializeField] private RewardPopUp _rewardPopUp;
    [SerializeField] private LevelCompletePopUp _levelCompletePopUp;
    [SerializeField] private OfflineRewardsPopUp _offlineRewardPopUp;
    [SerializeField] private EffectPanel _effectPanel;

    public RewardPopUp RewardPopUp => _rewardPopUp;
    public GamePlayPanel GamePlayPanel => _gamePlayPanel;
    public PopUpPanel PopUpPanel => _popUpPanel;
    public LevelCompletePopUp LevelCompletePopUp => _levelCompletePopUp;
    public OfflineRewardsPopUp OfflineRewardPopUp => _offlineRewardPopUp;

    public bool ShowingPopUp => RewardPopUp.Showing || PopUpPanel.Showing || LevelCompletePopUp.Showing || OfflineRewardPopUp.Showing;
    public EffectPanel EffectPanel => _effectPanel;
    public bool FirstTime
    {
        get => PrefManager.GetBool(nameof(FirstTime), true);
        private set => PrefManager.SetBool(nameof(FirstTime), value);
    }

    public long LastPlayedTime
    {
        get => PrefManager.GetLong(nameof(LastPlayedTime), DateTime.Now.Ticks);
        private set => PrefManager.SetLong(nameof(LastPlayedTime), value);
    }


    private void Awake()
    {
        Instance = this;
    }

    private void Start()
    {
        if (!FirstTime)
        {
            _offlineRewardPopUp.Money =
                LevelManager.GetOfflineRewards((int)DateTime.Now.Subtract(new DateTime(LastPlayedTime)).TotalSeconds);
            _offlineRewardPopUp.Show();
        }

        if (FirstTime)
            FirstTime = false;
    }

    private void Update()
    {
        LastPlayedTime = DateTime.Now.Ticks;
    }

    private void OnApplicationQuit()
    {
        LastPlayedTime = DateTime.Now.Ticks;
    }
}