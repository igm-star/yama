﻿// /*
// Created by Darsan
// */

using System;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Button))]
public class DisableButtonIfNoAds : MonoBehaviour
{
    private Button _button;

    private void Awake()
    {
        _button = GetComponent<Button>();
    }

    private void LateUpdate()
    {
        _button.interactable = AdsManager.IsVideoAvailable();
    }
}