﻿// /*
// Created by Darsan
// */

using Model;
using UnityEngine;

public class BallUpgradePopOverPanel : ShowHidable
{

    [SerializeField] private RectTransform _popOverPoint;
    [SerializeField] private PartUpgradeBtn _speedBtn, _earningBtn, _countBtn;

    private Ball _ball;



    public float PopOverPointX
    {
        get => _popOverPoint.transform.position.x;  
        set => _popOverPoint.transform.position = _popOverPoint.transform.position.WithX(value);
    }
    public BallSystem BallSystem=>BallSystem.Instance;

    public Ball Ball
    {
        get => _ball;
        set
        {
            _ball = value;
            RefreshProperties();
        }
    }

    private void Start()
    {
        _countBtn.Clicked += PropertyBtnOnClicked;
        _earningBtn.Clicked += PropertyBtnOnClicked;
        _speedBtn.Clicked += PropertyBtnOnClicked;
    }

    private void PropertyBtnOnClicked(SimpleBtn obj)
    {
        var partUpgradeBtn = (PartUpgradeBtn)obj;

        if (partUpgradeBtn.UseCoins)
        {
            ResourceManager.Coins -= partUpgradeBtn.MViewModel.LockDetails.unlockCoins;
            BallSystem.UpdateProperty(Ball.groupId,partUpgradeBtn.MViewModel.SystemProperty);
        }
        else
        {
            if (!AdsManager.IsVideoAvailable())
            {
                var popUpPanel = UIManager.Instance.PopUpPanel;
                popUpPanel.ShowAsInfo("No Ads", "Please turn on your internet connection!");
                return;
            }

            AdsManager.ShowVideoAds(true,success =>
            {
                if (success)
                    BallSystem.UpdateProperty(Ball.groupId, partUpgradeBtn.MViewModel.SystemProperty);

            });
        }


    }

    protected override void OnEnable()
    {
        base.OnEnable();
        BallSystem.PropertyUpgraded+=BallSystemOnPropertyUpgraded;
    }

    protected override void OnDisable()
    {
        base.OnDisable();
        BallSystem.PropertyUpgraded-=BallSystemOnPropertyUpgraded;
    }

    private void BallSystemOnPropertyUpgraded(string id, ISystemProperty property)
    {
        RefreshProperties();
    }

    private void RefreshProperties(params string[] properties)
    {
        if (properties.Length == 0)
        {
            RefreshProperties(nameof(Game.Ball.Speed), nameof(Game.Ball.Earning), "Count");
            return;
        }

        foreach (var property in properties)
        {
            PartUpgradeBtn btn = null;
            switch (property)
            {
                case nameof(Game.Ball.Speed):
                    btn = _speedBtn;
                    break;

                case nameof(Game.Ball.Earning):
                    btn = _earningBtn;
                    break;

                case "Count":
                    btn = _countBtn;
                    break;
            }
            if(btn!=null)
            {
                btn.MViewModel = new PartUpgradeBtn.ViewModel
                {
                    SystemProperty = BallSystem.GetUpgradeProperty(Ball.groupId, property),
                    LockDetails = BallSystem.GetLockDetailsForUpgrade(Ball.groupId, property),
                    Value = BallSystem.GetCurrentProperty(Ball.groupId,property).Value
                };
            }
        }
    }
}